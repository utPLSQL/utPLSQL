set serveroutput on
exec utplsql.test('checksum',recompile_in=>FALSE);
