CREATE OR REPLACE PACKAGE checksum AS

  FUNCTION calculate RETURN NUMBER;
  FUNCTION is_this_correct ( p_checksum NUMBER ) RETURN BOOLEAN;

END;
/

CREATE OR REPLACE PACKAGE BODY checksum AS

  FUNCTION calculate RETURN NUMBER IS
  BEGIN
    RETURN(10);
  END calculate;

  FUNCTION is_this_correct ( p_checksum NUMBER ) RETURN BOOLEAN IS
    v_ret_val BOOLEAN := FALSE;
  BEGIN
    IF calculate = p_checksum THEN
      v_ret_val := TRUE;
    END IF;
    RETURN(v_ret_val);
  END is_this_correct;

END;
/
