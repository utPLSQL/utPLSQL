CREATE OR REPLACE PACKAGE ut_CHECKSUM IS

  PROCEDURE ut_setup;
  PROCEDURE ut_teardown;
  
  PROCEDURE ut_CALCULATE;
  PROCEDURE ut_IS_THIS_CORRECT;

END ut_CHECKSUM;
/

CREATE OR REPLACE PACKAGE BODY ut_CHECKSUM IS

  v_first_run NUMBER;

  PROCEDURE ut_setup IS
  BEGIN
    v_first_run := checksum.calculate;
  END;

  PROCEDURE ut_teardown IS
  BEGIN
    NULL;
  END;

  FUNCTION does_it_run RETURN BOOLEAN IS
  BEGIN
    v_first_run := checksum.calculate;
    RETURN(TRUE);
  EXCEPTION
    WHEN OTHERS THEN
      RETURN(FALSE);
  END;

  PROCEDURE ut_CALCULATE IS
  BEGIN
    UTASSERT.THIS('Does it run',
                  does_it_run);
    UTASSERT.EQ('Same result on second run',
                checksum.calculate,
                v_first_run
                );
    UTASSERT.EQ('Same result on third run',
                checksum.calculate,
                v_first_run
                );
  END ut_CALCULATE;

  PROCEDURE ut_IS_THIS_CORRECT IS
  BEGIN
    UTASSERT.EQ('First comparison',
                checksum.is_this_correct(v_first_run),
                TRUE);
    UTASSERT.EQ('Second comparison',
                checksum.is_this_correct(v_first_run),
                TRUE);
  END ut_IS_THIS_CORRECT;

END ut_CHECKSUM;
/
