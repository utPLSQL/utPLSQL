declare
n number;
begin
calc_secs_between (sysdate, sysdate+1, n);
p.l (n);
end;
/
