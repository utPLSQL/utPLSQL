/* Only create new or modify existing structures */

ALTER TABLE ut_suite ADD last_status VARCHAR2(100);

DROP INDEX ut_package_idx1;

CREATE unique index ut_package_idx1 ON 
   ut_package (suite_id, owner, name);

ALTER TABLE ut_package ADD last_status VARCHAR2(100);

ALTER TABLE ut_config ADD registertest CHAR(1) DEFAULT 'N';

ALTER TABLE ut_config ADD directory VARCHAR2(2000);

ALTER TABLE ut_config ADD prefix VARCHAR2(100) DEFAULT 'ut_';
   
DELETE FROM ut_assertion WHERE name IN ('EQCOLL', 'EQCOLLAPI');

INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_dir,
   check_this_dir_label, 
   use_against_this_dir,
   against_this_dir_label 
   )
   VALUES (
   'EQCOLL',
   'Y',
   'Name of collection to be checked',
   'Y',
   'Name of collection to be checked against',
   'N',
   NULL,
   'N',
   NULL
   );

INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_dir,
   check_this_dir_label, 
   use_against_this_dir,
   against_this_dir_label 
   )
   VALUES (
   'EQCOLLAPI',
   'Y',
   'Name of collection to be checked',
   'Y',
   'Name of collection to be checked against',
   'N',
   NULL,
   'N',
   NULL
   );

COMMIT;

