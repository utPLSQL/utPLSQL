begin
   utsuite.add ('test');
   
   utpackage.add (utsuite.id_from_name('test'), 'te_employee', 
      add_tests_in => true,
      test_overloads_in => true);
end;
/
      