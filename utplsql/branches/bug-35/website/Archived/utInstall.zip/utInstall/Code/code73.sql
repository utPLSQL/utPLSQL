REM TEST FOR 7.3 Install (forced)

REM Create package specifications...

REM Detect version and set variables accordingly.
COLUMN col NOPRINT NEW_VALUE v_orcl_vers

SELECT 7.3 col
  FROM product_component_version
 WHERE UPPER(product) LIKE 'ORACLE7%'
    OR UPPER(product) LIKE 'PERSONAL ORACLE%'
    OR UPPER(product) LIKE 'ORACLE8%';

COLUMN col NOPRINT NEW_VALUE start81
SELECT DECODE (upper('&v_orcl_vers'),
               '8.1', '/* Use 8i code! */',
               '/* Ignore 8i code') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE end81
SELECT DECODE (upper('&v_orcl_vers'),
               '8.1', '/* Use 8i code! */',
               'Ignore 8i code */') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE start73
SELECT DECODE (upper('&v_orcl_vers'),
               '8.1', '/* Ignore Oracle7 code! ',
               '/* Use Oracle7 code */') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE end73
SELECT DECODE (upper('&v_orcl_vers'),
               '8.1', 'Ignore Oracle7 code! */',
               '/* Use Oracle7 code */') col  
  FROM dual;

@@utplsql.pks
@@utassert.pks
@@utresult.pks
@@utsuite.pks
@@utpackage.pks
@@uttest.pks
@@uttestcase.pks
@@utgen.pks

REM Create package bodies...

@@utplsql.pkb
@@utassert.pkb
@@utresult.pkb
@@utsuite.pkb
@@utpackage.pkb
@@uttest.pkb
@@uttestcase.pkb
@@utgen.pkb
