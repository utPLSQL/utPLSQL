DROP table ut_testcase;
DROP table ut_test;
DROP table ut_package;
DROP table ut_suite;
DROP table ut_assertion;
DROP table ut_config;

DROP sequence ut_suite_seq;
DROP sequence ut_package_seq;
DROP sequence ut_test_seq;
DROP sequence ut_testcase_seq;

DROP PACKAGE utplsql;
DROP PACKAGE utassert;
DROP PACKAGE utresult;
DROP PACKAGE utsuite;
DROP PACKAGE utpackage;
DROP PACKAGE uttest;
DROP PACKAGE uttestcase;
DROP PACKAGE utgen;

drop public synonym utplsql;
drop public synonym utresult;
drop public synonym utassert;
drop public synonym utsuite;
drop public synonym utpackage;
drop public synonym uttest;
drop public synonym uttestcase;
drop public synonym utgen;

drop public synonym ut_suite;
drop public synonym ut_package;
drop public synonym ut_test;
drop public synonym ut_testcase;
drop public synonym ut_assertion;
drop public synonym ut_config;
