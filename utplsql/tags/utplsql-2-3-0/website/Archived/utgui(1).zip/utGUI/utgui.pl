#!/usr/bin/perl -w 
################################################################################
#    utGui - a Perl Tk interface to the utPLSQL framework
#    Copyright (C) 2000  Chris Rimmer (chris@sunset.force9.co.uk)
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
################################################################################
# Version 1.1.0
#
# Modifications
# Who              When          What
# Chris Rimmer     04 Oct 2000   Created
# Chris Rimmer     24 Oct 2000   Added Refresh Button and ini File
#                                plus a few minor changes
################################################################################

use strict;
use Tk;
use DBI;

require Tk::DialogBox;

# The subroutine which populates the list box
sub fill_list;

# The subroutine which runs the tests
sub run_test;

# The subroutine which shows test details
sub show_details;

#####################################################
# The main routine
#####################################################

# The type of test to run 0 = package 1 = suite
my $test_type = 0;

# Make a main window 
my $mw = MainWindow->new;

# Set its title
$mw->title('utGUI');

my $bframe = $mw->Frame()->pack(-padx => 2, -pady => 2);

# Add a run button
$bframe->Button(
  -text => 'Run',
  -command => \&run_test) -> pack(-side => 'left', -padx => 1, -pady => 1);

# Add a refresh button
$bframe->Button(
  -text => 'Refresh',
  -command => \&fill_list) -> pack(-side => 'left', -padx => 1, -pady => 1);

# Add an exit button
$bframe->Button(
  -text => 'Exit',
  -command => sub {exit}) -> pack(-side => 'left', -padx => 1, -pady => 1);

# Add a packages radiobutton
$mw->Radiobutton
  (-text => 'Test Packages', 
   -value => 0, 
   -variable => \$test_type,
   -command => \&fill_list)->pack;

# Add a suites radiobutton
$mw->Radiobutton
  (-text => 'Test Suites', 
   -value => 1, 
   -variable => \$test_type,
   -command => \&fill_list
  )->pack;

# Add a listbox
my $list = $mw->Listbox(-selectmode=>'single', -background => 'white')->pack;

# Add a status item
$mw->Label(-text => 'Last Test')->pack;
  
my $status = $mw->Label
  (-text => 'None', 
   -background => 'white', 
   -relief => 'sunken'
  )->pack;

# Add a details button
$mw->Button(
  -text => 'Details',
  -command => \&show_details) -> pack(-padx => 3, -pady => 3);

# The connection parameters
my ($username, $password, $database) =("", "", "");

# The DB handle
my $dbh;

# So, lets get the username etc
my $connect = $mw->DialogBox
  (-title => "utGUI connection",
   -buttons => ["OK", "Cancel"]);

# Add username box
my $user_conn = $connect->add('Label', -text => 'Username')->pack;
$connect->add('Entry', 
  -width => 20, 
  -textvariable => \$username)->pack;

# Add password box
my $pass_conn = $connect->add('Label', -text => 'Password')->pack;
$connect->add('Entry', 
  -width => 20, 
  -show => '*', 
  -textvariable => \$password)->pack;

# Add database box
my $db_conn = $connect->add('Label', -text => 'Database')->pack;
$connect->add('Entry',
  -width => 20, 
  -textvariable => \$database)->pack;

#Try to determine the directory where utGUI is running from
#This assumes \ or / as directory separator 
my $dir = $0;
$dir =~ s/(.*[\/\\])[^\/\\]*$/$1/;

#Try to open the ini file there
if (open(FILE, $dir.'utgui.ini')){

  #Read a line
  my $line = <FILE>;
  chomp $line;

  #Split the data
  ($username, $database) = split /\s/, $line;

  close FILE;
} 

#Now try to connect
my $connected = 0;

# Keep going until we manage it
while($connected == 0){

  # Show the dialog
  my $button = $connect->Show;

  exit if ($button eq "Cancel");

  # Try to connect to the DB
  eval {
    $dbh = DBI->connect(
      "dbi:Oracle:$database",
      $username,$password, 
      { RaiseError => 1, PrintError => 0, AutoCommit => 0 }); 
  };

  # If something went wrong, show error
  if ($DBI::errstr) {

    $mw->messageBox
      (-title => "Connection Error",
       -message => $DBI::errstr,
       -type => 'OK');
  
  }else{
  
    # We are in!
    $connected = 1;
  }
}

#Try to open the ini file to write
if (open(FILE, '>'.$dir.'utgui.ini')){

  #Write out the username and database
  print FILE "$username $database";
  close FILE;
} 


# The statement to fetch package names
my $get_tests = $dbh->prepare(q{
  SELECT NAME 
  FROM UT_PACKAGE 
  ORDER BY NAME
});

# The statement to fetch suite names
my $get_suites = $dbh->prepare(q{
  SELECT NAME 
  FROM UT_SUITE 
  ORDER BY NAME
});

# The statement to run tests
my $run_test = $dbh->prepare(q{
  BEGIN
    UTPLSQL.TEST(?, reset_results_in => false);
  END;
});

# The statement to run test suites
my $run_suite = $dbh->prepare(q{
  BEGIN
    UTPLSQL.TESTSUITE(?, reset_results_in => false);
  END;
});

# The statement to retrieve test results
my $get_result = $dbh->prepare(q{
  BEGIN
    IF UTRESULT.SUCCESS THEN
      :result := 1;
    ELSE
      :result := 0;
    END IF;
  END;    
});

# The statement to retrieve test result details
my $get_details = $dbh->prepare(q{
  DECLARE
  
    --The record to hold details
    rec_details UTRESULT.result_rt := NULL;
    
    --The number of results
    num_results NUMBER := 0;
    
  BEGIN
  
    --Get the number of results
    num_results := UTRESULT.RESULTCOUNT;

    --Set message to null
    :message := '';
    
    --If there is anything to report
    IF num_results <> 0 THEN

      --Get the messages one by one
      FOR num_message IN 1..num_results
      LOOP

        --Pull in the result
        rec_details := UTRESULT.NTHRESULT(num_message);

        --Add to the message
        :message := :message || '
' || rec_details.msg;

      END LOOP;

    ELSE
      :message := 'No details available';
    END IF;
    
  END;
});

# Populate the list
fill_list;

# Start up the GUI
MainLoop;

##############################################################
# This fills the list with either test package or test suite
# names depending on the radiobutton selection
##############################################################
sub fill_list {

  # This holds the reference to the array of
  # (references to) names that comes back from 
  # the query
  my $ref;

  # Clear the list box
  $list->delete(0, 'end');

  # If test packages...
  if ($test_type == 0) {

    # Execute the query
    $get_tests->execute;

    # Get the ref to the results
    $ref = $get_tests->fetchall_arrayref;

  # If test suites...
  } else {

    # Execute the query
    $get_suites->execute;

    # Get the ref to the results
    $ref = $get_suites->fetchall_arrayref;
  }

  # Now fill the list
  foreach (@$ref){
    $list->insert('end', $$_[0]);
  }

}

######################################################
# This runs the currently selected test or test suite
# then gets the result and sets the status indicator
# in response 
######################################################
sub run_test {

  # List of selected indices (hopefully one)
  my @selection = $list->curselection();

  # Do nothing if nothing selected
  return if (@selection == 0);

  # Clear the status item
  $status->configure
    (-text => 'Running...', 
     -background => 'white', 
     -foreground => 'black');

  # Force it to update
  $status->update();

  # The selected test
  my $test = $list->get($selection[0]);

  # If test packages...
  if ($test_type == 0) {

    #Run the right test
    $run_test->execute($test);

  # If test suites
  } else {

    #Run the right suite
    $run_suite->execute($test);
  }

  # Now retrieve the results...
  my $result = 0;

  # Bind our Perl variable to the PL/SQL variable
  $get_result->bind_param_inout(":result", \$result, 20);

  # Run!
  $get_result->execute;

  # Set the status indicator
  if ($result == 1) {

    # It passed
    $status->configure
      (-text => "$test Succeeded", 
       -background => 'green', 
       -foreground => 'black');
  } else {

    # It failed
    $status->configure
      (-text => "$test Failed", 
       -background => 'red', 
       -foreground => 'white');
  }

}

##################################################
# This displays the details of the last test run
# in a message Box
##################################################
sub show_details {

  my $message = "";
  
  # Bind to the PL/SQL variable
  $get_details->bind_param_inout(":message", \$message, 2000);
  
  # Go get them
  $get_details->execute;
  
  # Show those details
  $mw->messageBox
    (-title => "Details",
     -message => $message,
     -type => 'OK');

}