----------------------------------------
utGUI 1.1.0
----------------------------------------

Copyright (c) 2000 Chris Rimmer (chris@sunset.force9.co.uk)

This software is released under the GNU General Public License
and comes with no warranty whatsoever.

See License.txt for more details.

----------------------------------------
Running
----------------------------------------

utGUI provides a simple Perl/Tk GUI interface to utPLSQL 
(see http://oracle.oreilly.com/utplsql) and was developed
using utPLSQL v1.5.3.  Hopefully it will work with 
other versions!  It has been tested on Windows NT 4.0,
Windows 2000 and Red Hat Linux 6.0, but should run on a 
variety of other platforms.

On start up, it displays a login screen to connect to the 
database, then provides a list of test packages or suites
defined.

To test one, select it, then press [Run].  The status indicator 
will show if the test run passed or failed.  On failure, the
[Details] button will show details of tests that failed.

To refresh the contents of the list, press [Refresh].

----------------------------------------
Installation
----------------------------------------

utGUI requires no installation as such, other than copying to
a convenient location, but does require that you have a 
(recent-ish) version of Perl installed and the following modules:

DBI the database access module
  (see http://search.cpan.org/search?module=DBI)

DBD::Oracle the driver for Oracle
  (http://search.cpan.org/search?dist=DBD-Oracle)

Tk to provide GUI support
  (http://search.cpan.org/search?module=Tk)

You will need a compiler, plus Pro*C for DBD::Oracle.

Note that if you are on a Windows platform you may find it 
easier to install ActiveState Perl
  (http://www.activestate.com)
and install the pre-compiled packages from there.
  (http://www.activestate.com/PPMPackages/)

