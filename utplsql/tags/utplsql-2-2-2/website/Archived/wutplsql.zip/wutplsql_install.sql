CREATE OR REPLACE PACKAGE wutplsql_control AS

  c_no_status CONSTANT VARCHAR2(9) := '"6666CC"';
  c_success   CONSTANT VARCHAR2(9) := '"00FF00"';
  c_failure   CONSTANT VARCHAR2(9) := '"FF0000"';

  PROCEDURE print_status ( p_status VARCHAR2 );
  PROCEDURE print_date ( p_date DATE );

  TYPE vc2_type IS TABLE OF VARCHAR2(30)
    INDEX BY BINARY_INTEGER;
  PROCEDURE save_vc2_array ( p_array vc2_type );

END wutplsql_control;
/

CREATE OR REPLACE PACKAGE BODY wutplsql_control AS

  PROCEDURE print_status ( p_status VARCHAR2 ) IS
    v_colour VARCHAR2(9) := wutplsql_control.c_no_status;
  BEGIN
    IF p_status = 'SUCCESS' THEN
      v_colour := wutplsql_control.c_success;
    ELSIF p_status = 'FAILURE' THEN
         v_colour := wutplsql_control.c_failure;
    END IF;
    HTP.TABLEDATA(NVL(p_status,'NO_STATUS'),cattributes => 'BGCOLOR=' || v_colour);
  END print_status;

  PROCEDURE print_date ( p_date DATE ) IS
    v_disp_date VARCHAR2(20);
  BEGIN
    IF p_date IS NULL THEN
      v_disp_date := 'NO DATE';
    ELSE
      v_disp_date := TO_CHAR(p_date,'DD-MON-YYYY HH24:MI:SS');
    END IF;
    HTP.TABLEDATA(v_disp_date);
  END print_date;

  PROCEDURE save_vc2_array ( p_array vc2_type ) IS
  BEGIN
    NULL;
  END save_vc2_array;

END wutplsql_control;
/       

CREATE OR REPLACE PROCEDURE wutplsql_header AS
BEGIN
  HTP.PRN('<table COLS=1 WIDTH="100%" >');
  HTP.PRN('<tr>');
  HTP.PRN('<td BGCOLOR="#800080"><a href="index.htm"><img SRC="utplsql.jpg" BORDER=0 height=56 width=373></a></td>');
  HTP.PRN('</tr>');
  HTP.PRN('</table>');
END wutplsql_header;
/

CREATE OR REPLACE PROCEDURE wutplsql_home AS
BEGIN

  wutplsql_header;

  HTP.BIG(HTF.BOLD('Welcome To Your UTPLSQL Home Page'));
  HTP.TABLEOPEN;

  HTP.TABLEROWOPEN;
  HTP.TABLEDATA('<form action=wutplsql_show_suites> ' ||
                '<input type=submit value="Test Suites">' ||
                '</form>');
  HTP.TABLEDATA('<form action=wutplsql_show_packages> ' ||
                '<input type=submit value="Test Packages">' ||
                '</form>');
  HTP.TABLEDATA('<form action=wutplsql_add_suite> ' ||
                '<input type=submit value="Add Suite">' ||
                '</form>');
  HTP.TABLEDATA('<form action=wutplsql_gen_pkg> ' ||
                '<input type=submit value="Generate Test Package">' ||
                '</form>');
  HTP.TABLEROWCLOSE;

  HTP.TABLECLOSE;

END wutplsql_home;
/

CREATE OR REPLACE PROCEDURE wutplsql_show_suites AS

  CURSOR curs_get_suite IS
  SELECT *
    FROM ut_suite
  ORDER BY name;

  CURSOR curs_get_package ( cp_suite NUMBER ) IS
  SELECT *
    FROM ut_package
   WHERE suite_id = cp_suite
  ORDER BY name;

BEGIN
  
  wutplsql_header;

  HTP.BIG(HTF.BOLD('List Of Suites'));
  HTP.PRN('<BR><BR>');

  HTP.TABLEOPEN(cattributes => 'BORDER="1" CELLPADDING="2" CELSPACING=2');
  HTP.TABLEROWOPEN(cattributes => 'BGCOLOR="#6666CC"');
  HTP.TABLEHEADER('Suite');
  HTP.TABLEHEADER('Package');
  HTP.TABLEHEADER('Executions');
  HTP.TABLEHEADER('Failures');
  HTP.TABLEHEADER('Last Status');
  HTP.TABLEHEADER('Last Start');
  HTP.TABLEHEADER('Last End>');
  HTP.TABLEHEADER('Run');
  HTP.TABLEROWCLOSE;

  FOR v_suite_rec IN curs_get_suite LOOP

    HTP.PRN('<TR>');
    HTP.TABLEROWOPEN('LEFT','TOP');
    HTP.TABLEDATA(v_suite_rec.name);
    HTP.TABLEDATA('N/A');
    HTP.TABLEDATA(v_suite_rec.executions);
    HTP.TABLEDATA(v_suite_rec.failures);
    wutplsql_control.print_status(v_suite_rec.last_status);
    wutplsql_control.print_date(v_suite_rec.last_start);
    wutplsql_control.print_date(v_suite_rec.last_end);
    HTP.FORMHIDDEN('p_suite',v_suite_rec.name);
    HTP.TABLEDATA('<form action=wutplsql_run_suite> '        ||
                  HTF.FORMHIDDEN('p_suite',v_suite_rec.name) ||
                  '<input type=submit value="Run Suite">'    ||
                  '</form>');

    HTP.TABLEROWCLOSE;

    FOR v_package_rec IN curs_get_package(v_suite_rec.id) LOOP

      HTP.TABLEROWOPEN('LEFT','TOP');
      HTP.TABLEDATA('N/A');
      HTP.TABLEDATA(v_package_rec.name);
      HTP.TABLEDATA(v_package_rec.executions);
      HTP.TABLEDATA(v_package_rec.failures);
      wutplsql_control.print_status(v_package_rec.last_status);
      wutplsql_control.print_date(v_package_rec.last_start);
      wutplsql_control.print_date(v_package_rec.last_end);
      HTP.TABLEDATA('N/A');
      HTP.TABLEROWCLOSE;

    END LOOP;

  END LOOP;

  HTP.TABLECLOSE;

END wutplsql_show_suites;
/

CREATE OR REPLACE PROCEDURE wutplsql_run_suite ( p_suite VARCHAR2 ) IS
  v_result UTRESULT.RESULT_RT;
BEGIN

  wutplsql_header;

  HTP.BIG('Running ' || p_suite || '<BR>');

  UTRESULT.INIT;
  UTPLSQL.TESTSUITE(p_suite,FALSE,FALSE);

  HTP.TABLEOPEN;
  HTP.TABLEROWOPEN;

  IF UTRESULT.SUCCESS THEN
    wutplsql_control.print_status('SUCCESS');
  ELSE
    wutplsql_control.print_status('FAILURE');
  END IF;

  HTP.TABLEROWCLOSE;
  HTP.TABLECLOSE;

  IF UTRESULT.RESULTCOUNT = 0 THEN
  
    HTP.PRN('<BR>');
    HTP.BOLD('No Messages');
  
  ELSE

    HTP.PRN('<TABLE BORDER=1>');
    HTP.PRN('<TR>');
    HTP.PRN('<TH>Name</TH>');
    HTP.PRN('<TH>Msg</TH>');
    HTP.PRN('<TH>Index</TH>');
    HTP.PRN('</TR>');

    FOR counter IN 1..UTRESULT.RESULTCOUNT LOOP
      v_result := UTRESULT.NTHRESULT(counter);
      HTP.PRN('<TR>');
      HTP.TABLEDATA(v_result.name);
      HTP.TABLEDATA(v_result.msg);
      HTP.TABLEDATA(v_result.indx);
      HTP.PRN('</TR>');
    END LOOP;

    HTP.PRN('</TABLE>');

  END IF;

END wutplsql_run_suite;
/

CREATE OR REPLACE PROCEDURE wutplsql_show_packages AS

  CURSOR curs_get_package IS
  SELECT *
    FROM ut_package
   WHERE suite_id IS NULL
  ORDER BY name;

  CURSOR curs_get_test ( cp_package NUMBER ) IS
  SELECT *
    FROM ut_test
   WHERE package_id = cp_package
  ORDER BY name;

BEGIN
  
  wutplsql_header;

  HTP.BIG(HTF.BOLD('List Of Packages'));
  HTP.PRN('<BR><BR>');

  HTP.TABLEOPEN(cattributes => 'BORDER="1" CELLPADDING="2" CELSPACING=2');
  HTP.TABLEROWOPEN(cattributes => 'BGCOLOR="#6666CC"');
  HTP.TABLEHEADER('Package');
  HTP.TABLEHEADER('Test');
  HTP.TABLEHEADER('Executions');
  HTP.TABLEHEADER('Failures');
  HTP.TABLEHEADER('Last Status');
  HTP.TABLEHEADER('Last Start');
  HTP.TABLEHEADER('Last End');
  HTP.TABLEHEADER('Run');
  HTP.TABLEROWCLOSE;

  FOR v_package_rec IN curs_get_package LOOP

    HTP.TABLEROWOPEN('LEFT','TOP');
    HTP.TABLEDATA(v_package_rec.name);
    HTP.TABLEDATA('N/A');
    HTP.TABLEDATA(v_package_rec.executions);
    HTP.TABLEDATA(v_package_rec.failures);
    wutplsql_control.print_status(v_package_rec.last_status);
    wutplsql_control.print_date(v_package_rec.last_start);
    wutplsql_control.print_date(v_package_rec.last_end);
    HTP.TABLEDATA('<form action=wutplsql_run_package> '          ||
                  HTF.FORMHIDDEN('p_package',v_package_rec.name) ||
                  '<input type=submit value="Run Package">'      ||
                  '</form>');
    HTP.PRN('</TR>');

    FOR v_test_rec IN curs_get_test(v_package_rec.id) LOOP

      HTP.PRN('<TR>');
      HTP.TABLEDATA('');
      HTP.TABLEDATA(v_test_rec.name);
      HTP.TABLEDATA(v_test_rec.executions);
      HTP.TABLEDATA(v_test_rec.failures);
      HTP.TABLEDATA('N/A');
      wutplsql_control.print_date(v_test_rec.last_start);
      wutplsql_control.print_date(v_test_rec.last_end);
      HTP.PRN('</TR>');

    END LOOP;

  END LOOP;

  HTP.PRN('</TABLE>');

END wutplsql_show_packages;
/

CREATE OR REPLACE PROCEDURE wutplsql_run_package ( p_package VARCHAR2 ) IS
  v_result UTRESULT.RESULT_RT;
BEGIN

  wutplsql_header;

  HTP.BIG('Running ' || p_package || '<BR>');

  UTRESULT.INIT;
  UTPLSQL.TEST(p_package,recompile_in=>FALSE,reset_results_in=>FALSE);

  HTP.TABLEOPEN;
  HTP.TABLEROWOPEN;

  IF UTRESULT.SUCCESS THEN
    wutplsql_control.print_status('SUCCESS');
  ELSE
    wutplsql_control.print_status('FAILURE');
  END IF;

  HTP.TABLEROWCLOSE;
  HTP.TABLECLOSE;

  IF UTRESULT.RESULTCOUNT = 0 THEN
  
    HTP.PRN('<BR>');
    HTP.BOLD('No Messages');
  
  ELSE

    HTP.PRN('<TABLE BORDER=1>');
    HTP.PRN('<TR>');
    HTP.PRN('<TH>Name</TH>');
    HTP.PRN('<TH>Msg</TH>');
    HTP.PRN('<TH>Index</TH>');
    HTP.PRN('</TR>');

    FOR counter IN 1..UTRESULT.RESULTCOUNT LOOP
      v_result := UTRESULT.NTHRESULT(counter);
      HTP.PRN('<TR>');
      HTP.TABLEDATA(v_result.name);
      HTP.TABLEDATA(v_result.msg);
      HTP.TABLEDATA(v_result.indx);
      HTP.PRN('</TR>');
    END LOOP;

    HTP.PRN('</TABLE>');

  END IF;

END wutplsql_run_package;
/

CREATE OR REPLACE PROCEDURE wutplsql_add_suite AS

  CURSOR curs_get_package IS
  SELECT *
    FROM ut_package
   WHERE suite_id IS NULL
  ORDER BY name;

BEGIN

  wutplsql_header;

  HTP.BIG('Create Suite');

  HTP.PRN('<form ACTION="wutplsql_actually_add_suite">');

  HTP.PRN('<input name=p_suite>');

  HTP.FORMSELECTOPEN(cname => 'p_package',
                     cattributes => 'MULTIPLE');
  HTP.PRN('<OPTION>No Package');
  FOR v_package_rec IN curs_get_package LOOP
    HTP.PRN('<OPTION>' || v_package_rec.name);
  END LOOP;
  HTP.FORMSELECTCLOSE;
  HTP.PRN('<input type=submit value="Save">');

END wutplsql_add_suite;
/

CREATE OR REPLACE PROCEDURE wutplsql_actually_add_suite ( p_suite   varchar2,
                                                          p_package wutplsql_control.vc2_type ) AS
BEGIN

  UTSUITE.ADD(p_suite);

  IF NOT ( p_package.COUNT = 1 AND
           p_package(1) = 'No Package' ) THEN
    FOR counter IN 1..p_package.COUNT LOOP
      UTPACKAGE.ADD(p_suite,p_package(counter));
    END LOOP;
  END IF;

  wutplsql_header;

  HTP.BOLD('Suite Added');

END wutplsql_actually_add_suite;
/

CREATE OR REPLACE PROCEDURE wutplsql_gen_pkg AS
BEGIN
  wutplsql_header;
  HTP.BIG('Generate Package');
  HTP.PRN('<form ACTION="wutplsql_actually_gen_pkg">');
  HTP.PRN('<input name=p_pkg>');
  HTP.PRN('<input type=submit value="Generate">');
  HTP.PRN('<form>');
END wutplsql_gen_pkg;
/

CREATE OR REPLACE PROCEDURE wutplsql_actually_gen_pkg ( p_pkg VARCHAR2 ) AS
BEGIN

  wutplsql_header;

  utgen.testpkg(p_pkg,output_type_in => utGen.c_array);

  FOR counter IN UTGEN.FIRSTROW..UTGEN.LASTROW LOOP
    HTP.PRN(UTGEN.GETROW || '<BR>');
    UTGEN.NEXTROW;
  END LOOP;

END wutplsql_actually_gen_pkg;
/
