create or replace package BODY ut_plvstr
IS
   PROCEDURE ut_setup
   IS
   BEGIN
      NULL;
   END;

   PROCEDURE ut_teardown
   IS
   BEGIN
      utPLSQL.registertest (TRUE);
      utPLSQL.addtest ('betwn_numbers');
      utPLSQL.addtest ('betwn_characters');
      utPLSQL.registertest (FALSE);
   END;

   PROCEDURE ut_betwn_numbers
   IS
      str VARCHAR2 (2000) := 'this is not much of a string';
      str2 VARCHAR2 (2000) := 'I like this function';
   BEGIN
      utassert.eq (
         'Typical execution',
         PLVstr.betwn (str2, 3, 6),
         'like'
      );
      
      utassert.eq (
         'Between spaces',
         PLVstr.betwn (str, 6, 11),
         'is not'
      );
      
      utassert.isnull (
         'Test zeroes',
         PLVstr.betwn (str, 0, 0)
      );
      
      utassert.eq (
         'Past end',
         PLVstr.betwn (str, 6, 500),
         'is not much of a string'
      );
      
      utassert.eq (
         'Test negative start',
         PLVstr.betwn (str, -6, -8),
         'a s'
      );
      
   END;
   
   PROCEDURE ut_betwn_characters
   IS
      str VARCHAR2 (2000) := 'this is not muc|h of a st*ring';
   BEGIN
      utassert.eq (
         'Between spaces',
         PLVstr.betwn (str, 'not', 'muc|h'),
         'not muc|h'
      );
      
      utassert.eq (
         '2nd occurrence',
         PLVstr.betwn (str, 'is', 'muc|h', 2),
         'is not muc|h'
      );
      
      utassert.eq (
         'Not inclusive',
         PLVstr.betwn (str, '|', '*', inclusive => FALSE),
         'h of a st'
      );
      
      utassert.eq (
         'Go to end',
         PLVstr.betwn (str, '|', '^', gotoend => TRUE),
         '|h of a st*ring'
      );
      
   END;
   
END ut_plvstr;
/
