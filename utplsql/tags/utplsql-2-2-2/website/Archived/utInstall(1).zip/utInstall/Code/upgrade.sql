SPOOL upgrade.log

@@tablesupg

@@code

SPOOL OFF
