REM
REM Install utPLSQL v2.0.4
REM
SET VERIFY OFF
SET FEEDBACK OFF
TTITLE OFF
SET SERVEROUTPUT ON SIZE 1000000 FORMAT WRAPPED
COLUMN col NOPRINT NEW_VALUE v_orcl_vers

SELECT SUBSTR(version,1,3) col
  FROM product_component_version
 WHERE UPPER(PRODUCT) LIKE 'ORACLE7%'
    OR UPPER(PRODUCT) LIKE 'PERSONAL ORACLE%'
    OR UPPER(PRODUCT) LIKE 'ORACLE8%';

COLUMN col NOPRINT NEW_VALUE start81
SELECT DECODE (UPPER('&v_orcl_vers'),
               '8.1', '/* Use 8i code! */',
               '/* Ignore 8i code') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE end81
SELECT DECODE (upper('&v_orcl_vers'),
               '8.1', '/* Use 8i code! */',
               'Ignore 8i code */') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE start73
SELECT DECODE (UPPER('&v_orcl_vers'),
               '8.1', '/* Ignore Oracle7 code! ',
               '/* Use Oracle7 code */') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE end73
SELECT DECODE (UPPER('&v_orcl_vers'),
               '8.1', 'Ignore Oracle7 code! */',
               '/* Use Oracle7 code */') col  
  FROM dual;
  
SET VERIFY OFF
SET FEEDBACK ON

SPOOL utplsql_install.log
@@install_tables
@@install_views
@@install_sequences
@@install_packages
@@grant_access
@@install_synonyms
@@verify_install
spool off
