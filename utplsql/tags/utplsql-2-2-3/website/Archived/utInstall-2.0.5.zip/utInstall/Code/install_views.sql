/* Formatted on 2001/07/14 09:15 (RevealNet Formatter v4.4.1) */
CREATE OR REPLACE VIEW utv_result_full
AS
   SELECT utp.id utp_id, program, ut.id unittest_id,
          tc.id testcase_id, utr.outcome_id, run_id,
          start_on, end_on, status, utr.description
     FROM ut_utp utp,
          ut_unittest ut,
          ut_testcase tc,
          ut_outcome oc,
          utr_outcome utr
    WHERE utp.id = ut.utp_id
      AND ut.id = tc.unittest_id
      AND tc.id = oc.testcase_id
      AND oc.id = utr.outcome_id;

CREATE OR REPLACE VIEW utv_last_run
AS
   SELECT a.id utp_id, program, run_id last_run_id
     FROM ut_utp a,
          (SELECT   utp_id, MAX (run_id) run_id
               FROM utv_result_full
           GROUP BY utp_id) b
    WHERE a.id = b.utp_id(+);

