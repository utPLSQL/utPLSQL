REM DO NOT MODIFY THIS FILE
REM OraShare, an open source Oracle installer utility
REM For more information, contact steven@stevenfeuerstein.com
REM 
REM Generated Install Script for utplsql for All Versions
REM Generated on 02/07/2001 01:08:54
REM 
REM
REM Set SQL*Plus substitution variables for version-specific code
REM
SET VERIFY OFF
SET FEEDBACK OFF
SET SERVEROUTPUT ON SIZE 1000000 FORMAT WRAPPED
COLUMN col NOPRINT NEW_VALUE v_orcl_vers

SELECT SUBSTR(version,1,3) col
  FROM product_component_version
 WHERE UPPER(PRODUCT) LIKE 'ORACLE7%'
    OR UPPER(PRODUCT) LIKE 'PERSONAL ORACLE%'
    OR UPPER(PRODUCT) LIKE 'ORACLE8%';

COLUMN col NOPRINT NEW_VALUE start81
SELECT DECODE (UPPER('&v_orcl_vers'),
               '8.1', '/* Use 8i code! */',
               '/* Ignore 8i code') col
  FROM dual;

COLUMN col NOPRINT NEW_VALUE end81
SELECT DECODE (upper('&v_orcl_vers'),
               '8.1', '/* Use 8i code! */',
               'Ignore 8i code */') col
  FROM dual;

COLUMN col NOPRINT NEW_VALUE start73
SELECT DECODE (UPPER('&v_orcl_vers'),
               '8.1', '/* Ignore Oracle7 code! ',
               '/* Use Oracle7 code */') col
  FROM dual;

COLUMN col NOPRINT NEW_VALUE end73
SELECT DECODE (UPPER('&v_orcl_vers'),
               '8.1', 'Ignore Oracle7 code! */',
               '/* Use Oracle7 code */') col
  FROM dual;
SET VERIFY ON
SET FEEDBACK ON
REM Create PACKAGEs...
REM 
prompt Creating UTCONFIG...
@@utconfig.pks
prompt Creating UTPLSQL...
@@utplsql.pks
prompt Creating UTCONFIG...
@@utconfig.pks
prompt Creating UTASSERT...
@@utassert.pks
prompt Creating UTRESULT...
@@utresult.pks
prompt Creating UTSUITE...
@@utsuite.pks
prompt Creating UTPACKAGE...
@@utpackage.pks
prompt Creating UTTEST...
@@uttest.pks
prompt Creating UTTESTCASE...
@@uttestcase.pks
prompt Creating UTGEN...
@@utgen.pks
REM 
REM Create PACKAGE BODYs...
REM 
prompt Creating UTCONFIG...
@@utconfig.pkb
prompt Creating UTPLSQL...
@@utplsql.pkb
prompt Creating UTCONFIG...
@@utconfig.pkb
prompt Creating UTASSERT...
@@utassert.pkb
prompt Creating UTRESULT...
@@utresult.pkb
prompt Creating UTSUITE...
@@utsuite.pkb
prompt Creating UTPACKAGE...
@@utpackage.pkb
prompt Creating UTTEST...
@@uttest.pkb
prompt Creating UTTESTCASE...
@@uttestcase.pkb
prompt Creating UTGEN...
@@utgen.pkb
REM 
REM Create PROCEDUREs...
REM 
REM 
REM Create FUNCTIONs...
REM 
REM 
REM Create TRIGGERs...
REM 
REM 
REM Create JAVAs...
REM 
REM 
REM Grant privileges...
REM 
GRANT ALL ON UT_CONFIG TO PUBLIC;
GRANT ALL ON UT_ASSERTION TO PUBLIC;
GRANT ALL ON UT_SUITE TO PUBLIC;
GRANT ALL ON UT_PACKAGE TO PUBLIC;
GRANT ALL ON UT_TEST TO PUBLIC;
GRANT ALL ON UT_TESTCASE TO PUBLIC;
GRANT EXECUTE ON UTCONFIG TO PUBLIC;
GRANT EXECUTE ON UTPLSQL TO PUBLIC;
GRANT EXECUTE ON UTCONFIG TO PUBLIC;
GRANT EXECUTE ON UTASSERT TO PUBLIC;
GRANT EXECUTE ON UTRESULT TO PUBLIC;
GRANT EXECUTE ON UTSUITE TO PUBLIC;
GRANT EXECUTE ON UTPACKAGE TO PUBLIC;
GRANT EXECUTE ON UTTEST TO PUBLIC;
GRANT EXECUTE ON UTTESTCASE TO PUBLIC;
GRANT EXECUTE ON UTGEN TO PUBLIC;
REM 
REM Create synonyms...
REM 
CREATE PUBLIC SYNONYM UT_CONFIG FOR UT_CONFIG;
CREATE PUBLIC SYNONYM UT_ASSERTION FOR UT_ASSERTION;
CREATE PUBLIC SYNONYM UT_SUITE FOR UT_SUITE;
CREATE PUBLIC SYNONYM UT_PACKAGE FOR UT_PACKAGE;
CREATE PUBLIC SYNONYM UT_TEST FOR UT_TEST;
CREATE PUBLIC SYNONYM UT_TESTCASE FOR UT_TESTCASE;
CREATE PUBLIC SYNONYM UTCONFIG FOR UTCONFIG;
CREATE PUBLIC SYNONYM UTPLSQL FOR UTPLSQL;
CREATE PUBLIC SYNONYM UTCONFIG FOR UTCONFIG;
CREATE PUBLIC SYNONYM UTASSERT FOR UTASSERT;
CREATE PUBLIC SYNONYM UTRESULT FOR UTRESULT;
CREATE PUBLIC SYNONYM UTSUITE FOR UTSUITE;
CREATE PUBLIC SYNONYM UTPACKAGE FOR UTPACKAGE;
CREATE PUBLIC SYNONYM UTTEST FOR UTTEST;
CREATE PUBLIC SYNONYM UTTESTCASE FOR UTTESTCASE;
CREATE PUBLIC SYNONYM UTGEN FOR UTGEN;
DEFINE app_name = utplsql
REM
REM Verify installation of application
REM
SET VERIFY OFF
DECLARE
   l_successful BOOLEAN := TRUE;
   indx PLS_INTEGER;
   TYPE object_rt IS RECORD (
       n VARCHAR2(30), t VARCHAR2(30), MSG VARCHAR2(100));
   TYPE object_tt IS TABLE OF object_rt INDEX BY BINARY_INTEGER;
   invalids object_tt;
   nosyns object_tt;

   PROCEDURE load_arrays IS BEGIN
invalids(1).n := 'UT_CONFIG';
invalids(1).t := 'TABLE';
nosyns(1).n := 'UT_CONFIG';
nosyns(1).t := 'TABLE';
invalids(2).n := 'UT_ASSERTION';
invalids(2).t := 'TABLE';
nosyns(2).n := 'UT_ASSERTION';
nosyns(2).t := 'TABLE';
invalids(3).n := 'UT_SUITE';
invalids(3).t := 'TABLE';
nosyns(3).n := 'UT_SUITE';
nosyns(3).t := 'TABLE';
invalids(4).n := 'UT_PACKAGE';
invalids(4).t := 'TABLE';
nosyns(4).n := 'UT_PACKAGE';
nosyns(4).t := 'TABLE';
invalids(5).n := 'UT_TEST';
invalids(5).t := 'TABLE';
nosyns(5).n := 'UT_TEST';
nosyns(5).t := 'TABLE';
invalids(6).n := 'UT_TESTCASE';
invalids(6).t := 'TABLE';
nosyns(6).n := 'UT_TESTCASE';
nosyns(6).t := 'TABLE';
invalids(1073741825).n := 'UTCONFIG';
invalids(1073741825).t := 'PACKAGE';
invalids(1073751825).n := 'UTCONFIG';
invalids(1073751825).t := 'PACKAGE BODY';
nosyns(1073741825).n := 'UTCONFIG';
nosyns(1073741825).t := 'PACKAGE';
invalids(1073741826).n := 'UTPLSQL';
invalids(1073741826).t := 'PACKAGE';
invalids(1073751826).n := 'UTPLSQL';
invalids(1073751826).t := 'PACKAGE BODY';
nosyns(1073741826).n := 'UTPLSQL';
nosyns(1073741826).t := 'PACKAGE';
invalids(1073741827).n := 'UTCONFIG';
invalids(1073741827).t := 'PACKAGE';
invalids(1073751827).n := 'UTCONFIG';
invalids(1073751827).t := 'PACKAGE BODY';
nosyns(1073741827).n := 'UTCONFIG';
nosyns(1073741827).t := 'PACKAGE';
invalids(1073741828).n := 'UTASSERT';
invalids(1073741828).t := 'PACKAGE';
invalids(1073751828).n := 'UTASSERT';
invalids(1073751828).t := 'PACKAGE BODY';
nosyns(1073741828).n := 'UTASSERT';
nosyns(1073741828).t := 'PACKAGE';
invalids(1073741829).n := 'UTRESULT';
invalids(1073741829).t := 'PACKAGE';
invalids(1073751829).n := 'UTRESULT';
invalids(1073751829).t := 'PACKAGE BODY';
nosyns(1073741829).n := 'UTRESULT';
nosyns(1073741829).t := 'PACKAGE';
invalids(1073741830).n := 'UTSUITE';
invalids(1073741830).t := 'PACKAGE';
invalids(1073751830).n := 'UTSUITE';
invalids(1073751830).t := 'PACKAGE BODY';
nosyns(1073741830).n := 'UTSUITE';
nosyns(1073741830).t := 'PACKAGE';
invalids(1073741831).n := 'UTPACKAGE';
invalids(1073741831).t := 'PACKAGE';
invalids(1073751831).n := 'UTPACKAGE';
invalids(1073751831).t := 'PACKAGE BODY';
nosyns(1073741831).n := 'UTPACKAGE';
nosyns(1073741831).t := 'PACKAGE';
invalids(1073741832).n := 'UTTEST';
invalids(1073741832).t := 'PACKAGE';
invalids(1073751832).n := 'UTTEST';
invalids(1073751832).t := 'PACKAGE BODY';
nosyns(1073741832).n := 'UTTEST';
nosyns(1073741832).t := 'PACKAGE';
invalids(1073741833).n := 'UTTESTCASE';
invalids(1073741833).t := 'PACKAGE';
invalids(1073751833).n := 'UTTESTCASE';
invalids(1073751833).t := 'PACKAGE BODY';
nosyns(1073741833).n := 'UTTESTCASE';
nosyns(1073741833).t := 'PACKAGE';
invalids(1073741834).n := 'UTGEN';
invalids(1073741834).t := 'PACKAGE';
invalids(1073751834).n := 'UTGEN';
invalids(1073751834).t := 'PACKAGE BODY';
nosyns(1073741834).n := 'UTGEN';
nosyns(1073741834).t := 'PACKAGE';
   END;

   FUNCTION object_not_valid (
      NAME_IN   IN   VARCHAR2,
      type_IN   IN   VARCHAR2
   )
      RETURN BOOLEAN
   IS
      l_status user_objects.status%TYPE;
   BEGIN
      SELECT status
        INTO l_status
        FROM user_objects
       WHERE object_name = UPPER (NAME_IN)
         AND object_type = UPPER (TYPE_IN);
      RETURN (l_status != 'VALID');
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN TRUE;
   END;

   FUNCTION synonym_not_valid (name_in IN VARCHAR2)
      RETURN BOOLEAN
   IS
      l_status user_objects.status%TYPE;
   BEGIN
      SELECT 'X'
        INTO l_status
        FROM all_synonyms
       WHERE owner = 'PUBLIC'
         AND synonym_name = name_in
         AND table_name = name_in
         AND table_owner = USER;
      RETURN FALSE;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN TRUE;
   END;

   PROCEDURE add_failure (
      list_in IN OUT object_tt,
      indx_in   IN   PLS_INTEGER, msg_in IN VARCHAR2 := NULL
   )
   IS
   BEGIN
      l_successful := FALSE;
      list_in(indx_in).MSG := msg_in;
   END;
BEGIN
   load_arrays;
   indx := invalids.FIRST;
   LOOP
      EXIT WHEN indx IS NULL;

      IF object_not_valid (invalids (indx).n, invalids (indx).t)
      THEN
         add_failure (invalids, indx,
            invalids (indx).t || ' ' || invalids (indx).n ||
                   ' failed TO install properly.');
      ELSE
         invalids.DELETE (indx);
      END IF;

      indx := invalids.NEXT (indx);
   END LOOP;

   indx := nosyns.FIRST;
   LOOP
      EXIT WHEN indx IS NULL;

      IF synonym_not_valid (nosyns(indx).n)
      THEN
         add_failure (nosyns, indx, 'PUBLIC SYNONYM NOT created FOR ' ||
            nosyns (indx).n);
      ELSE
         nosyns.DELETE (indx);
      END IF;

      indx := nosyns.NEXT (indx);
   END LOOP;

   IF NOT l_successful
   THEN
      DBMS_OUTPUT.PUT_LINE ('WARNING: Unsuccessful installation OF "&app_name"!');
      indx := invalids.FIRST;
      LOOP
         EXIT WHEN indx IS NULL;
         DBMS_OUTPUT.PUT_LINE (invalids(indx).MSG);
         indx := invalids.NEXT (indx);
      END LOOP;
      indx := nosyns.FIRST;
      LOOP
         EXIT WHEN indx IS NULL;
         DBMS_OUTPUT.PUT_LINE (nosyns(indx).MSG);
         indx := nosyns.NEXT (indx);
      END LOOP;
   ELSE
      DBMS_OUTPUT.PUT_LINE ('SUCCESSFUL installation OF "&app_name" completed!');
   END IF;
END;
/
SPOOL  OFF
UNDEFINE app_name
