REM DO NOT MODIFY THIS FILE
REM OraShare, an open source Oracle installer utility
REM For more information, contact steven@stevenfeuerstein.com
REM 
REM Generated Install Script for utplsql for All Versions
REM Generated on 07/14/2001 07:54:29
REM 
REM
REM Set SQL*Plus substitution variables for version-specific code
REM
SET VERIFY OFF
SET FEEDBACK OFF
SET SERVEROUTPUT ON SIZE 1000000 FORMAT WRAPPED
COLUMN col NOPRINT NEW_VALUE v_orcl_vers

SELECT SUBSTR(version,1,3) col
  FROM product_component_version
 WHERE UPPER(PRODUCT) LIKE 'ORACLE7%'
    OR UPPER(PRODUCT) LIKE 'PERSONAL ORACLE%'
    OR UPPER(PRODUCT) LIKE 'ORACLE8%';

COLUMN col NOPRINT NEW_VALUE start81
SELECT DECODE (UPPER('&v_orcl_vers'),
               '8.1', '/* Use 8i code! */',
               '/* Ignore 8i code') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE end81
SELECT DECODE (upper('&v_orcl_vers'),
               '8.1', '/* Use 8i code! */',
               'Ignore 8i code */') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE start73
SELECT DECODE (UPPER('&v_orcl_vers'),
               '8.1', '/* Ignore Oracle7 code! ',
               '/* Use Oracle7 code */') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE end73
SELECT DECODE (UPPER('&v_orcl_vers'),
               '8.1', 'Ignore Oracle7 code! */',
               '/* Use Oracle7 code */') col  
  FROM dual;
SET VERIFY ON
SET FEEDBACK ON
SPOOL utplsql_install.log
REM 
REM Create TABLEs...
REM 
prompt Creating UT_CONFIG...
@@ut_config.tab
prompt Creating UT_ASSERTION...
@@ut_assertion.tab
prompt Creating UT_SUITE...
@@ut_suite.tab
prompt Creating UT_PACKAGE...
@@ut_package.tab
prompt Creating UT_TEST...
@@ut_test.tab
prompt Creating UT_TESTCASE...
@@ut_testcase.tab
prompt Creating UT_UTP...
@@ut_utp.tab
prompt Creating UT_TESTPREP...
@@ut_testprep.tab
prompt Creating UT_UNITTEST...
@@ut_unittest.tab
prompt Creating UT_TESTCASE2...
@@ut_testcase2.tab
prompt Creating UT_OUTCOME...
@@ut_outcome.tab
prompt Creating UT_EQ...
@@ut_eq.tab
prompt Creating UT_SUITE_UTP...
@@ut_suite_utp.tab
prompt Creating UTR_SUITE...
@@utr_suite.tab
prompt Creating UTR_UTP...
@@utr_utp.tab
prompt Creating UTR_UNITTEST...
@@utr_unittest.tab
prompt Creating UTR_TESTCASE...
@@utr_testcase.tab
prompt Creating UTR_OUTCOME...
@@utr_outcome.tab
prompt Creating UTR_ERROR...
@@utr_error.tab
REM 
REM Create VIEWs...
REM 
REM 
REM Create TYPEs...
REM 
REM 
REM Create SEQUENCEs...
REM 
prompt Creating UT_SUITE_SEQ...
@@ut_suite_seq.seq
prompt Creating UT_PACKAGE_SEQ...
@@ut_package_seq.seq
prompt Creating UT_UTP_SEQ...
@@ut_utp_seq.seq
prompt Creating UT_TEST_SEQ...
@@ut_test_seq.seq
prompt Creating UT_TESTCASE_SEQ...
@@ut_testcase_seq.seq
prompt Creating UTPLSQL_RUNNUM_SEQ...
@@utplsql_runnum_seq.seq
REM 
REM Create PACKAGEs...
REM 
prompt Creating UTCONFIG...
@@utconfig.pks
prompt Creating UTASSERT...
@@utassert.pks
prompt Creating UTPLSQL...
@@utplsql.pks
prompt Creating UTRESULT...
@@utresult.pks
prompt Creating UTASSERT2...
@@utassert2.pks
prompt Creating UTPLSQL2...
@@utplsql2.pks
prompt Creating UTRESULT2...
@@utresult2.pks
prompt Creating UTUTP...
@@ututp.pks
prompt Creating UTTESTPREP...
@@uttestprep.pks
prompt Creating UTUNITTEST...
@@utunittest.pks
prompt Creating UTTESTCASE...
@@uttestcase.pks
prompt Creating UTOUTCOME...
@@utoutcome.pks
prompt Creating UTSUITEUTP...
@@utsuiteutp.pks
prompt Creating UTSUITE...
@@utsuite.pks
prompt Creating UTPACKAGE...
@@utpackage.pks
prompt Creating UTTEST...
@@uttest.pks
prompt Creating UTGEN...
@@utgen.pks
prompt Creating UTRSUITE...
@@utrsuite.pks
prompt Creating UTRUTP...
@@utrutp.pks
prompt Creating UTRUNITTEST...
@@utrunittest.pks
prompt Creating UTRTESTCASE...
@@utrtestcase.pks
prompt Creating UTROUTCOME...
@@utroutcome.pks
prompt Creating UTRERROR...
@@utrerror.pks
REM 
REM Create PACKAGE BODYs...
REM 
prompt Creating UTCONFIG...
@@utconfig.pkb
prompt Creating UTASSERT...
@@utassert.pkb
prompt Creating UTPLSQL...
@@utplsql.pkb
prompt Creating UTRESULT...
@@utresult.pkb
prompt Creating UTASSERT2...
@@utassert2.pkb
prompt Creating UTPLSQL2...
@@utplsql2.pkb
prompt Creating UTRESULT2...
@@utresult2.pkb
prompt Creating UTUTP...
@@ututp.pkb
prompt Creating UTTESTPREP...
@@uttestprep.pkb
prompt Creating UTUNITTEST...
@@utunittest.pkb
prompt Creating UTTESTCASE...
@@uttestcase.pkb
prompt Creating UTOUTCOME...
@@utoutcome.pkb
prompt Creating UTSUITEUTP...
@@utsuiteutp.pkb
prompt Creating UTSUITE...
@@utsuite.pkb
prompt Creating UTPACKAGE...
@@utpackage.pkb
prompt Creating UTTEST...
@@uttest.pkb
prompt Creating UTGEN...
@@utgen.pkb
prompt Creating UTRSUITE...
@@utrsuite.pkb
prompt Creating UTRUTP...
@@utrutp.pkb
prompt Creating UTRUNITTEST...
@@utrunittest.pkb
prompt Creating UTRTESTCASE...
@@utrtestcase.pkb
prompt Creating UTROUTCOME...
@@utroutcome.pkb
prompt Creating UTRERROR...
@@utrerror.pkb
REM 
REM Create PROCEDUREs...
REM 
REM 
REM Create FUNCTIONs...
REM 
REM 
REM Create TRIGGERs...
REM 
REM 
REM Create JAVAs...
REM 
REM 
REM Grant privileges...
REM 
GRANT ALL ON UT_SUITE_SEQ TO PUBLIC;
GRANT ALL ON UT_PACKAGE_SEQ TO PUBLIC;
GRANT ALL ON UT_UTP_SEQ TO PUBLIC;
GRANT ALL ON UT_TEST_SEQ TO PUBLIC;
GRANT ALL ON UT_TESTCASE_SEQ TO PUBLIC;
GRANT ALL ON UTPLSQL_RUNNUM_SEQ TO PUBLIC;
GRANT ALL ON UT_CONFIG TO PUBLIC;
GRANT ALL ON UT_ASSERTION TO PUBLIC;
GRANT ALL ON UT_SUITE TO PUBLIC;
GRANT ALL ON UT_PACKAGE TO PUBLIC;
GRANT ALL ON UT_TEST TO PUBLIC;
GRANT ALL ON UT_TESTCASE TO PUBLIC;
GRANT ALL ON UT_UTP TO PUBLIC;
GRANT ALL ON UT_TESTPREP TO PUBLIC;
GRANT ALL ON UT_UNITTEST TO PUBLIC;
GRANT ALL ON UT_TESTCASE2 TO PUBLIC;
GRANT ALL ON UT_OUTCOME TO PUBLIC;
GRANT ALL ON UT_EQ TO PUBLIC;
GRANT ALL ON UT_SUITE_UTP TO PUBLIC;
GRANT ALL ON UTR_SUITE TO PUBLIC;
GRANT ALL ON UTR_UTP TO PUBLIC;
GRANT ALL ON UTR_UNITTEST TO PUBLIC;
GRANT ALL ON UTR_TESTCASE TO PUBLIC;
GRANT ALL ON UTR_OUTCOME TO PUBLIC;
GRANT ALL ON UTR_ERROR TO PUBLIC;
GRANT EXECUTE ON UTCONFIG TO PUBLIC;
GRANT EXECUTE ON UTASSERT TO PUBLIC;
GRANT EXECUTE ON UTPLSQL TO PUBLIC;
GRANT EXECUTE ON UTRESULT TO PUBLIC;
GRANT EXECUTE ON UTASSERT2 TO PUBLIC;
GRANT EXECUTE ON UTPLSQL2 TO PUBLIC;
GRANT EXECUTE ON UTRESULT2 TO PUBLIC;
GRANT EXECUTE ON UTUTP TO PUBLIC;
GRANT EXECUTE ON UTTESTPREP TO PUBLIC;
GRANT EXECUTE ON UTUNITTEST TO PUBLIC;
GRANT EXECUTE ON UTTESTCASE TO PUBLIC;
GRANT EXECUTE ON UTOUTCOME TO PUBLIC;
GRANT EXECUTE ON UTSUITEUTP TO PUBLIC;
GRANT EXECUTE ON UTSUITE TO PUBLIC;
GRANT EXECUTE ON UTPACKAGE TO PUBLIC;
GRANT EXECUTE ON UTTEST TO PUBLIC;
GRANT EXECUTE ON UTGEN TO PUBLIC;
GRANT EXECUTE ON UTRSUITE TO PUBLIC;
GRANT EXECUTE ON UTRUTP TO PUBLIC;
GRANT EXECUTE ON UTRUNITTEST TO PUBLIC;
GRANT EXECUTE ON UTRTESTCASE TO PUBLIC;
GRANT EXECUTE ON UTROUTCOME TO PUBLIC;
GRANT EXECUTE ON UTRERROR TO PUBLIC;
REM 
REM Create synonyms...
REM 
CREATE PUBLIC SYNONYM UTCONFIG FOR UTCONFIG;
CREATE PUBLIC SYNONYM UT_ASSERTION FOR UT_ASSERTION;
CREATE PUBLIC SYNONYM UT_SUITE FOR UT_SUITE;
CREATE PUBLIC SYNONYM UTASSERT FOR UTASSERT;
CREATE PUBLIC SYNONYM UT_TEST FOR UT_TEST;
CREATE PUBLIC SYNONYM UT_TESTCASE FOR UT_TESTCASE;
CREATE PUBLIC SYNONYM UT_SUITE_SEQ FOR UT_SUITE_SEQ;
CREATE PUBLIC SYNONYM UT_PACKAGE_SEQ FOR UT_PACKAGE_SEQ;
CREATE PUBLIC SYNONYM UT_UTP_SEQ FOR UT_UTP_SEQ;
CREATE PUBLIC SYNONYM UT_TEST_SEQ FOR UT_TEST_SEQ;
CREATE PUBLIC SYNONYM UT_TESTCASE_SEQ FOR UT_TESTCASE_SEQ;
CREATE PUBLIC SYNONYM UTPLSQL_RUNNUM_SEQ FOR UTPLSQL_RUNNUM_SEQ;
CREATE PUBLIC SYNONYM UT_UTP FOR UT_UTP;
CREATE PUBLIC SYNONYM UT_TESTPREP FOR UT_TESTPREP;
CREATE PUBLIC SYNONYM UT_UNITTEST FOR UT_UNITTEST;
CREATE PUBLIC SYNONYM UT_TESTCASE2 FOR UT_TESTCASE2;
CREATE PUBLIC SYNONYM UT_OUTCOME FOR UT_OUTCOME;
CREATE PUBLIC SYNONYM UT_EQ FOR UT_EQ;
CREATE PUBLIC SYNONYM UT_SUITE_UTP FOR UT_SUITE_UTP;
CREATE PUBLIC SYNONYM UTR_SUITE FOR UTR_SUITE;
CREATE PUBLIC SYNONYM UTR_UTP FOR UTR_UTP;
CREATE PUBLIC SYNONYM UTR_UNITTEST FOR UTR_UNITTEST;
CREATE PUBLIC SYNONYM UTR_TESTCASE FOR UTR_TESTCASE;
CREATE PUBLIC SYNONYM UTR_OUTCOME FOR UTR_OUTCOME;
CREATE PUBLIC SYNONYM UTR_ERROR FOR UTR_ERROR;
CREATE PUBLIC SYNONYM UTPLSQL FOR UTPLSQL;
CREATE PUBLIC SYNONYM UTRESULT FOR UTRESULT;
CREATE PUBLIC SYNONYM UTASSERT2 FOR UTASSERT2;
CREATE PUBLIC SYNONYM UTPLSQL2 FOR UTPLSQL2;
CREATE PUBLIC SYNONYM UTRESULT2 FOR UTRESULT2;
CREATE PUBLIC SYNONYM UTUTP FOR UTUTP;
CREATE PUBLIC SYNONYM UTTESTPREP FOR UTTESTPREP;
CREATE PUBLIC SYNONYM UTUNITTEST FOR UTUNITTEST;
CREATE PUBLIC SYNONYM UTTESTCASE FOR UTTESTCASE;
CREATE PUBLIC SYNONYM UTOUTCOME FOR UTOUTCOME;
CREATE PUBLIC SYNONYM UTSUITEUTP FOR UTSUITEUTP;
CREATE PUBLIC SYNONYM UTSUITE FOR UTSUITE;
CREATE PUBLIC SYNONYM UTPACKAGE FOR UTPACKAGE;
CREATE PUBLIC SYNONYM UTTEST FOR UTTEST;
CREATE PUBLIC SYNONYM UTGEN FOR UTGEN;
CREATE PUBLIC SYNONYM UTRSUITE FOR UTRSUITE;
CREATE PUBLIC SYNONYM UTRUTP FOR UTRUTP;
CREATE PUBLIC SYNONYM UTRUNITTEST FOR UTRUNITTEST;
CREATE PUBLIC SYNONYM UTRTESTCASE FOR UTRTESTCASE;
CREATE PUBLIC SYNONYM UTROUTCOME FOR UTROUTCOME;
CREATE PUBLIC SYNONYM UTRERROR FOR UTRERROR;
DEFINE app_name = utplsql
REM
REM Verify installation of application
REM
SET VERIFY OFF
DECLARE
   l_successful BOOLEAN := TRUE;
   indx PLS_INTEGER;
   TYPE object_rt IS RECORD (
       n VARCHAR2(30), t VARCHAR2(30), MSG VARCHAR2(100));
   TYPE object_tt IS TABLE OF object_rt INDEX BY BINARY_INTEGER;
   invalids object_tt;
   nosyns object_tt;
   
   PROCEDURE load_arrays IS BEGIN
invalids(1).n := 'UTCONFIG';
invalids(1).t := 'PACKAGE';
invalids(10001).n := 'UTCONFIG';
invalids(10001).t := 'PACKAGE BODY';
nosyns(1).n := 'UTCONFIG';
nosyns(1).t := 'PACKAGE';
invalids(2).n := 'UT_ASSERTION';
invalids(2).t := 'TABLE';
nosyns(2).n := 'UT_ASSERTION';
nosyns(2).t := 'TABLE';
invalids(3).n := 'UT_SUITE';
invalids(3).t := 'TABLE';
nosyns(3).n := 'UT_SUITE';
nosyns(3).t := 'TABLE';
invalids(4).n := 'UTASSERT';
invalids(4).t := 'PACKAGE';
invalids(10004).n := 'UTASSERT';
invalids(10004).t := 'PACKAGE BODY';
nosyns(4).n := 'UTASSERT';
nosyns(4).t := 'PACKAGE';
invalids(5).n := 'UT_TEST';
invalids(5).t := 'TABLE';
nosyns(5).n := 'UT_TEST';
nosyns(5).t := 'TABLE';
invalids(6).n := 'UT_TESTCASE';
invalids(6).t := 'TABLE';
nosyns(6).n := 'UT_TESTCASE';
nosyns(6).t := 'TABLE';
invalids(1073741825).n := 'UT_SUITE_SEQ';
invalids(1073741825).t := 'SEQUENCE';
nosyns(1073741825).n := 'UT_SUITE_SEQ';
nosyns(1073741825).t := 'SEQUENCE';
invalids(1073741826).n := 'UT_PACKAGE_SEQ';
invalids(1073741826).t := 'SEQUENCE';
nosyns(1073741826).n := 'UT_PACKAGE_SEQ';
nosyns(1073741826).t := 'SEQUENCE';
invalids(1073741827).n := 'UT_UTP_SEQ';
invalids(1073741827).t := 'SEQUENCE';
nosyns(1073741827).n := 'UT_UTP_SEQ';
nosyns(1073741827).t := 'SEQUENCE';
invalids(1073741828).n := 'UT_TEST_SEQ';
invalids(1073741828).t := 'SEQUENCE';
nosyns(1073741828).n := 'UT_TEST_SEQ';
nosyns(1073741828).t := 'SEQUENCE';
invalids(1073741829).n := 'UT_TESTCASE_SEQ';
invalids(1073741829).t := 'SEQUENCE';
nosyns(1073741829).n := 'UT_TESTCASE_SEQ';
nosyns(1073741829).t := 'SEQUENCE';
invalids(1073741830).n := 'UTPLSQL_RUNNUM_SEQ';
invalids(1073741830).t := 'SEQUENCE';
nosyns(1073741830).n := 'UTPLSQL_RUNNUM_SEQ';
nosyns(1073741830).t := 'SEQUENCE';
invalids(1073741831).n := 'UT_UTP';
invalids(1073741831).t := 'TABLE';
nosyns(1073741831).n := 'UT_UTP';
nosyns(1073741831).t := 'TABLE';
invalids(1073741832).n := 'UT_TESTPREP';
invalids(1073741832).t := 'TABLE';
nosyns(1073741832).n := 'UT_TESTPREP';
nosyns(1073741832).t := 'TABLE';
invalids(1073741833).n := 'UT_UNITTEST';
invalids(1073741833).t := 'TABLE';
nosyns(1073741833).n := 'UT_UNITTEST';
nosyns(1073741833).t := 'TABLE';
invalids(1073741834).n := 'UT_TESTCASE2';
invalids(1073741834).t := 'TABLE';
nosyns(1073741834).n := 'UT_TESTCASE2';
nosyns(1073741834).t := 'TABLE';
invalids(1073741835).n := 'UT_OUTCOME';
invalids(1073741835).t := 'TABLE';
nosyns(1073741835).n := 'UT_OUTCOME';
nosyns(1073741835).t := 'TABLE';
invalids(1073741836).n := 'UT_EQ';
invalids(1073741836).t := 'TABLE';
nosyns(1073741836).n := 'UT_EQ';
nosyns(1073741836).t := 'TABLE';
invalids(1073741837).n := 'UT_SUITE_UTP';
invalids(1073741837).t := 'TABLE';
nosyns(1073741837).n := 'UT_SUITE_UTP';
nosyns(1073741837).t := 'TABLE';
invalids(1073741838).n := 'UTR_SUITE';
invalids(1073741838).t := 'TABLE';
nosyns(1073741838).n := 'UTR_SUITE';
nosyns(1073741838).t := 'TABLE';
invalids(1073741839).n := 'UTR_UTP';
invalids(1073741839).t := 'TABLE';
nosyns(1073741839).n := 'UTR_UTP';
nosyns(1073741839).t := 'TABLE';
invalids(1073741840).n := 'UTR_UNITTEST';
invalids(1073741840).t := 'TABLE';
nosyns(1073741840).n := 'UTR_UNITTEST';
nosyns(1073741840).t := 'TABLE';
invalids(1073741841).n := 'UTR_TESTCASE';
invalids(1073741841).t := 'TABLE';
nosyns(1073741841).n := 'UTR_TESTCASE';
nosyns(1073741841).t := 'TABLE';
invalids(1073741842).n := 'UTR_OUTCOME';
invalids(1073741842).t := 'TABLE';
nosyns(1073741842).n := 'UTR_OUTCOME';
nosyns(1073741842).t := 'TABLE';
invalids(1073741843).n := 'UTR_ERROR';
invalids(1073741843).t := 'TABLE';
nosyns(1073741843).n := 'UTR_ERROR';
nosyns(1073741843).t := 'TABLE';
invalids(1073741844).n := 'UTPLSQL';
invalids(1073741844).t := 'PACKAGE';
invalids(1073751844).n := 'UTPLSQL';
invalids(1073751844).t := 'PACKAGE BODY';
nosyns(1073741844).n := 'UTPLSQL';
nosyns(1073741844).t := 'PACKAGE';
invalids(1073741845).n := 'UTRESULT';
invalids(1073741845).t := 'PACKAGE';
invalids(1073751845).n := 'UTRESULT';
invalids(1073751845).t := 'PACKAGE BODY';
nosyns(1073741845).n := 'UTRESULT';
nosyns(1073741845).t := 'PACKAGE';
invalids(1073741846).n := 'UTASSERT2';
invalids(1073741846).t := 'PACKAGE';
invalids(1073751846).n := 'UTASSERT2';
invalids(1073751846).t := 'PACKAGE BODY';
nosyns(1073741846).n := 'UTASSERT2';
nosyns(1073741846).t := 'PACKAGE';
invalids(1073741847).n := 'UTPLSQL2';
invalids(1073741847).t := 'PACKAGE';
invalids(1073751847).n := 'UTPLSQL2';
invalids(1073751847).t := 'PACKAGE BODY';
nosyns(1073741847).n := 'UTPLSQL2';
nosyns(1073741847).t := 'PACKAGE';
invalids(1073741848).n := 'UTRESULT2';
invalids(1073741848).t := 'PACKAGE';
invalids(1073751848).n := 'UTRESULT2';
invalids(1073751848).t := 'PACKAGE BODY';
nosyns(1073741848).n := 'UTRESULT2';
nosyns(1073741848).t := 'PACKAGE';
invalids(1073741849).n := 'UTUTP';
invalids(1073741849).t := 'PACKAGE';
invalids(1073751849).n := 'UTUTP';
invalids(1073751849).t := 'PACKAGE BODY';
nosyns(1073741849).n := 'UTUTP';
nosyns(1073741849).t := 'PACKAGE';
invalids(1073741850).n := 'UTTESTPREP';
invalids(1073741850).t := 'PACKAGE';
invalids(1073751850).n := 'UTTESTPREP';
invalids(1073751850).t := 'PACKAGE BODY';
nosyns(1073741850).n := 'UTTESTPREP';
nosyns(1073741850).t := 'PACKAGE';
invalids(1073741851).n := 'UTUNITTEST';
invalids(1073741851).t := 'PACKAGE';
invalids(1073751851).n := 'UTUNITTEST';
invalids(1073751851).t := 'PACKAGE BODY';
nosyns(1073741851).n := 'UTUNITTEST';
nosyns(1073741851).t := 'PACKAGE';
invalids(1073741852).n := 'UTTESTCASE';
invalids(1073741852).t := 'PACKAGE';
invalids(1073751852).n := 'UTTESTCASE';
invalids(1073751852).t := 'PACKAGE BODY';
nosyns(1073741852).n := 'UTTESTCASE';
nosyns(1073741852).t := 'PACKAGE';
invalids(1073741853).n := 'UTOUTCOME';
invalids(1073741853).t := 'PACKAGE';
invalids(1073751853).n := 'UTOUTCOME';
invalids(1073751853).t := 'PACKAGE BODY';
nosyns(1073741853).n := 'UTOUTCOME';
nosyns(1073741853).t := 'PACKAGE';
invalids(1073741854).n := 'UTSUITEUTP';
invalids(1073741854).t := 'PACKAGE';
invalids(1073751854).n := 'UTSUITEUTP';
invalids(1073751854).t := 'PACKAGE BODY';
nosyns(1073741854).n := 'UTSUITEUTP';
nosyns(1073741854).t := 'PACKAGE';
invalids(1073741855).n := 'UTSUITE';
invalids(1073741855).t := 'PACKAGE';
invalids(1073751855).n := 'UTSUITE';
invalids(1073751855).t := 'PACKAGE BODY';
nosyns(1073741855).n := 'UTSUITE';
nosyns(1073741855).t := 'PACKAGE';
invalids(1073741856).n := 'UTPACKAGE';
invalids(1073741856).t := 'PACKAGE';
invalids(1073751856).n := 'UTPACKAGE';
invalids(1073751856).t := 'PACKAGE BODY';
nosyns(1073741856).n := 'UTPACKAGE';
nosyns(1073741856).t := 'PACKAGE';
invalids(1073741857).n := 'UTTEST';
invalids(1073741857).t := 'PACKAGE';
invalids(1073751857).n := 'UTTEST';
invalids(1073751857).t := 'PACKAGE BODY';
nosyns(1073741857).n := 'UTTEST';
nosyns(1073741857).t := 'PACKAGE';
invalids(1073741858).n := 'UTGEN';
invalids(1073741858).t := 'PACKAGE';
invalids(1073751858).n := 'UTGEN';
invalids(1073751858).t := 'PACKAGE BODY';
nosyns(1073741858).n := 'UTGEN';
nosyns(1073741858).t := 'PACKAGE';
invalids(1073741859).n := 'UTRSUITE';
invalids(1073741859).t := 'PACKAGE';
invalids(1073751859).n := 'UTRSUITE';
invalids(1073751859).t := 'PACKAGE BODY';
nosyns(1073741859).n := 'UTRSUITE';
nosyns(1073741859).t := 'PACKAGE';
invalids(1073741860).n := 'UTRUTP';
invalids(1073741860).t := 'PACKAGE';
invalids(1073751860).n := 'UTRUTP';
invalids(1073751860).t := 'PACKAGE BODY';
nosyns(1073741860).n := 'UTRUTP';
nosyns(1073741860).t := 'PACKAGE';
invalids(1073741861).n := 'UTRUNITTEST';
invalids(1073741861).t := 'PACKAGE';
invalids(1073751861).n := 'UTRUNITTEST';
invalids(1073751861).t := 'PACKAGE BODY';
nosyns(1073741861).n := 'UTRUNITTEST';
nosyns(1073741861).t := 'PACKAGE';
invalids(1073741862).n := 'UTRTESTCASE';
invalids(1073741862).t := 'PACKAGE';
invalids(1073751862).n := 'UTRTESTCASE';
invalids(1073751862).t := 'PACKAGE BODY';
nosyns(1073741862).n := 'UTRTESTCASE';
nosyns(1073741862).t := 'PACKAGE';
invalids(1073741863).n := 'UTROUTCOME';
invalids(1073741863).t := 'PACKAGE';
invalids(1073751863).n := 'UTROUTCOME';
invalids(1073751863).t := 'PACKAGE BODY';
nosyns(1073741863).n := 'UTROUTCOME';
nosyns(1073741863).t := 'PACKAGE';
invalids(1073741864).n := 'UTRERROR';
invalids(1073741864).t := 'PACKAGE';
invalids(1073751864).n := 'UTRERROR';
invalids(1073751864).t := 'PACKAGE BODY';
nosyns(1073741864).n := 'UTRERROR';
nosyns(1073741864).t := 'PACKAGE';
invalids(1073741865).n := 'UT_CONFIG';
invalids(1073741865).t := 'TABLE';
nosyns(1073741865).n := 'UT_CONFIG';
nosyns(1073741865).t := 'TABLE';
invalids(1073741866).n := 'UT_PACKAGE';
invalids(1073741866).t := 'TABLE';
nosyns(1073741866).n := 'UT_PACKAGE';
nosyns(1073741866).t := 'TABLE';
   END;

   FUNCTION object_not_valid (
      NAME_IN   IN   VARCHAR2,
      type_IN   IN   VARCHAR2
   )
      RETURN BOOLEAN
   IS
      l_status user_objects.status%TYPE;
   BEGIN
      SELECT status
        INTO l_status
        FROM user_objects
       WHERE object_name = UPPER (NAME_IN)
         AND object_type = UPPER (TYPE_IN);
      RETURN (l_status != 'VALID');
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN TRUE;
   END;

   FUNCTION synonym_not_valid (name_in IN VARCHAR2)
      RETURN BOOLEAN
   IS
      l_status user_objects.status%TYPE;
   BEGIN
      SELECT 'X'
        INTO l_status
        FROM all_synonyms
       WHERE owner = 'PUBLIC'
         AND synonym_name = name_in
         AND table_name = name_in
         AND table_owner = USER;
      RETURN FALSE;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN TRUE;
   END;
   
   PROCEDURE add_failure (
      list_inout IN OUT object_tt,
      indx_in   IN   PLS_INTEGER, msg_in IN VARCHAR2 := NULL
   )
   IS
   BEGIN
      l_successful := FALSE;
      list_inout (indx_in).MSG := msg_in;
   END;
BEGIN
   load_arrays;
   indx := invalids.FIRST;
   LOOP
      EXIT WHEN indx IS NULL;

      IF object_not_valid (invalids (indx).n, invalids (indx).t)
      THEN
         add_failure (invalids, indx,
            invalids (indx).t || ' ' || invalids (indx).n ||
                   ' failed TO install properly.');
      ELSE
         invalids.DELETE (indx);
      END IF;
      
      indx := invalids.NEXT (indx);
   END LOOP;

   indx := nosyns.FIRST;
   LOOP
      EXIT WHEN indx IS NULL;

      IF synonym_not_valid (nosyns(indx).n)
      THEN
         add_failure (nosyns, indx, 'PUBLIC SYNONYM NOT created FOR ' ||
            nosyns (indx).n);
      ELSE
         nosyns.DELETE (indx);
      END IF;
      
      indx := nosyns.NEXT (indx);
   END LOOP;
   
   IF NOT l_successful
   THEN
      DBMS_OUTPUT.PUT_LINE ('WARNING: Unsuccessful installation OF "&app_name"!');
      indx := invalids.FIRST;
      LOOP
         EXIT WHEN indx IS NULL;
         DBMS_OUTPUT.PUT_LINE (invalids(indx).MSG);
         indx := invalids.NEXT (indx);
      END LOOP;
      indx := nosyns.FIRST;      
      LOOP
         EXIT WHEN indx IS NULL;
         DBMS_OUTPUT.PUT_LINE (nosyns(indx).MSG);
         indx := nosyns.NEXT (indx);
      END LOOP;      
   ELSE
      DBMS_OUTPUT.PUT_LINE ('SUCCESSFUL installation OF "&app_name" completed!');
   END IF;
END;
/
SPOOL  OFF
UNDEFINE app_name
