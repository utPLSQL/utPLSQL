SET SERVEROUTPUT ON SIZE 1000000
@@utverify.sp
exec utverify
