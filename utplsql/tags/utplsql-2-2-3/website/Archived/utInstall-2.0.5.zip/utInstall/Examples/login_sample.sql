exec utConfig.setdir ('YOUR DIRECTORY HERE')
REM exec utplsql.setdir ('e:\openoracle\utplsql\utinstall\examples')
SET SERVEROUTPUT ON SIZE 1000000 FORMAT WRAPPED
exec utConfig.showconfig
