Welcome to utPLSQL, the unit testing framework for PL/SQL

Copyright 2000, Steven Feuerstein, steven@stevenfeuerstein.com

You have downloaded utPLSQL. 

It is not warranted to be free of bugs. 

Use it at your own risk (but, believe me, there's nothing very risky about it).

TO INSTALL

1. Unzip the software into the directory of your choice. It will create three 
sub-directories: Code, Examples and Doc.

2. Open the doc/index.htm file and follow instructions in the Getting Started 
document for either installing or upgrading utPLSQL.

TO USE

Review the on-line documentation. Start with Getting Started, then check out
Build Test Packages and dip into the User Guide as needed. 

Any questions? Go to the utPLSQL Webboard at 

http://forums.oreilly.com/~utplsql/ 

and let us know about it.

  
Thanks, 
Steven Feuerstein

