/* 
GNU General Public License for utPLSQL
    
Copyright (C) 2000 Steven Feuerstein, steven@stevenfeuerstein.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (see license.txt); if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

CREATE TABLE ut_config (
   username VARCHAR2(100) PRIMARY KEY,
   autocompile CHAR(1) DEFAULT 'Y',
   registertest CHAR(1) DEFAULT 'N',
   directory VARCHAR2(2000),
   prefix VARCHAR2(100)
);
   
CREATE TABLE ut_assertion (
   name VARCHAR2(100) PRIMARY KEY,
   use_msg CHAR(1) DEFAULT 'Y',
   use_null_OK CHAR(1) DEFAULT 'Y',
   use_raise_exc CHAR(1) DEFAULT 'Y',
   use_check_this CHAR(1) DEFAULT 'Y',
   check_this_label VARCHAR2(100) 
      DEFAULT 'Check this',
   use_check_this_where CHAR(1) DEFAULT 'N',
   check_this_where_label VARCHAR2(100) 
      DEFAULT 'Check this WHERE clause',
   use_against_this CHAR(1) DEFAULT 'Y',
   against_this_label VARCHAR2(100) 
      DEFAULT 'Against this',
   use_against_this_where CHAR(1) DEFAULT 'N',
   against_this_where_label VARCHAR2(100) 
      DEFAULT 'Against this WHERE clause',
   use_check_this_dir CHAR(1) DEFAULT 'N',
   check_this_dir_label VARCHAR2(100) 
      DEFAULT 'Location of "check this" file',
   use_against_this_dir CHAR(1) DEFAULT 'N',
   against_this_dir_label VARCHAR2(100) 
      DEFAULT 'Location of "against this" file'
); 

INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_dir,
   check_this_dir_label, 
   use_against_this_dir,
   against_this_dir_label 
   )
   VALUES (
   'THIS',
   'Y',
   'Boolean expression',
   'N',
   NULL,
   'N',
   NULL,
   'N',
   NULL
   );
   
INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_dir,
   check_this_dir_label, 
   use_against_this_dir,
   against_this_dir_label 
   )
   VALUES (
   'EQ',
   'Y',
   'Test Outcome',
   'Y',
   'Base Data',
   'N',
   NULL,
   'N',
   NULL
   );
   
INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_where,
   check_this_where_label, 
   use_against_this_where,
   against_this_where_label 
   )
   VALUES (
   'EQTABLE',
   'Y',
   'Test Table',
   'Y',
   'Base Table',
   'Y',
   'WHERE clause of Test Table',
   'Y',
   'WHERE clause of Base Table'
   );
   
INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_where,
   check_this_where_label, 
   use_against_this_where,
   against_this_where_label 
   )
   VALUES (
   'EQTABCOUNT',
   'Y',
   'Test Table Count',
   'Y',
   'Base Table Count',
   'Y',
   'WHERE clause of Test Table',
   'Y',
   'WHERE clause of Base Table'
   );

INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_dir,
   check_this_dir_label, 
   use_against_this_dir,
   against_this_dir_label 
   )
   VALUES (
   'EQQUERY',
   'Y',
   'Test Query',
   'Y',
   'Base Query',
   'N',
   NULL,
   'N',
   NULL
   );
   
INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_dir,
   check_this_dir_label, 
   use_against_this_dir,
   against_this_dir_label 
   )
   VALUES (
   'EQFILE',
   'Y',
   'Test File',
   'Y',
   'Base File',
   'Y',
   'Location of test file',
   'Y',
   'Location of base file'
   );
   
INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_dir,
   check_this_dir_label, 
   use_against_this_dir,
   against_this_dir_label 
   )
   VALUES (
   'EQPIPE',
   'Y',
   'Test Pipe',
   'Y',
   'Base Pipe',
   'N',
   NULL,
   'N',
   NULL
   );

INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_dir,
   check_this_dir_label, 
   use_against_this_dir,
   against_this_dir_label 
   )
   VALUES (
   'ISNOTNULL',
   'Y',
   'Value to be checked',
   'N',
   NULL,
   'N',
   NULL,
   'N',
   NULL
   );

INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_dir,
   check_this_dir_label, 
   use_against_this_dir,
   against_this_dir_label 
   )
   VALUES (
   'ISNULL',
   'Y',
   'Value to be checked',
   'N',
   NULL,
   'N',
   NULL,
   'N',
   NULL
   );

INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_dir,
   check_this_dir_label, 
   use_against_this_dir,
   against_this_dir_label 
   )
   VALUES (
   'EQCOLL',
   'Y',
   'Name of collection to be checked',
   'Y',
   'Name of collection to be checked against',
   'N',
   NULL,
   'N',
   NULL
   );

INSERT INTO ut_assertion (
   name, 
   use_check_this,
   check_this_label, 
   use_against_this,
   against_this_label, 
   use_check_this_dir,
   check_this_dir_label, 
   use_against_this_dir,
   against_this_dir_label 
   )
   VALUES (
   'EQCOLLAPI',
   'Y',
   'Name of collection to be checked',
   'Y',
   'Name of collection to be checked against',
   'N',
   NULL,
   'N',
   NULL
   );

COMMIT;

CREATE TABLE ut_suite (
   id INTEGER PRIMARY KEY, 
   name VARCHAR2(200), 
   description VARCHAR2(2000), 
   executions INTEGER, 
   failures INTEGER,
   last_status VARCHAR2(20), /* either SUCCESS or FAILURE */
   last_start DATE, 
   last_end DATE
);

CREATE unique index ut_suite_idx1 ON 
   ut_suite (name);
   
CREATE TABLE ut_package (
   id INTEGER PRIMARY KEY, 
   suite_id INTEGER,
   owner VARCHAR2(30), 
   name VARCHAR2(200), 
   description VARCHAR2(2000),
   samepackage CHAR(1) DEFAULT 'N', 
   prefix VARCHAR2(100), 
   dir VARCHAR2(2000), 
   seq INTEGER, 
   executions INTEGER, 
   failures INTEGER,
   last_status VARCHAR2(20), /* either SUCCESS or FAILURE */
   last_start DATE, 
   last_end DATE
);

CREATE unique index ut_package_idx1 ON 
   ut_package (suite_id, owner, name);

ALTER table ut_package add CONSTRAINT ut_package_suite_fk
   FOREIGN KEY (suite_id) REFERENCES ut_suite;

CREATE TABLE ut_test (
   id INTEGER PRIMARY KEY, 
   package_id INTEGER, 
   name VARCHAR2(200), 
   description VARCHAR2(2000), 
   seq INTEGER, 
   executions INTEGER, 
   failures INTEGER,
   last_start DATE, 
   last_end DATE
); 

CREATE unique index ut_test_idx1 ON 
   ut_test (name);

ALTER table ut_test add CONSTRAINT ut_test_package_fk
   FOREIGN KEY (package_id) REFERENCES ut_package;

CREATE TABLE ut_testcase (
   id INTEGER PRIMARY KEY, 
   test_id INTEGER, 
   prefix VARCHAR2(200), 
   name VARCHAR2(200), 
   description VARCHAR2(2000),
   assertion VARCHAR2(100),
   inline_assertion_call CHAR(1) DEFAULT 'N', 
   seq INTEGER DEFAULT 1, 
   executions INTEGER, 
   failures INTEGER,
   last_start DATE, 
   last_end DATE
); 

CREATE unique index ut_testcase_idx1 ON 
   ut_testcase (name);

ALTER table ut_testcase add CONSTRAINT ut_testcase_test_fk
   FOREIGN KEY (test_id) REFERENCES ut_test;
   
ALTER table ut_testcase add CONSTRAINT ut_testcase_assertion_fk
   FOREIGN KEY (assertion) REFERENCES ut_assertion;
   
