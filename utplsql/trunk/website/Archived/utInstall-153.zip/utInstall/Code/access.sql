/* 
GNU General Public License for utPLSQL
    
Copyright (C) 2000 Steven Feuerstein, steven@stevenfeuerstein.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (see license.txt); if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

grant select on ut_suite to public;
grant select on ut_package to public;
grant select on ut_test to public;
grant select on ut_testcase to public;
grant select on ut_assertion to public;
grant select, insert, update on ut_config to public;

grant execute on utplsql to public;
grant execute on utassert to public;
grant execute on utsuite to public;
grant execute on utresult to public;
grant execute on utpackage to public;
grant execute on uttest to public;
grant execute on uttestcase to public;
grant execute on utgen to public;

create public synonym ut_suite for ut_suite;
create public synonym ut_package for ut_package;
create public synonym ut_test for ut_test;
create public synonym ut_testcase for ut_testcase;
create public synonym ut_assertion for ut_assertion;
create public synonym ut_config for ut_config;

create public synonym utplsql for utplsql;
create public synonym utassert for utassert;
create public synonym utsuite for utsuite;
create public synonym utresult for utresult;
create public synonym utpackage for utpackage;
create public synonym uttest for uttest;
create public synonym uttestcase for uttestcase;
create public synonym utgen for utgen;
