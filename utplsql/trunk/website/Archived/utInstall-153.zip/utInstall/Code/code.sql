/* 
GNU General Public License for utPLSQL
    
Copyright (C) 2000 Steven Feuerstein, steven@stevenfeuerstein.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (see license.txt); if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

REM Create package specifications...

REM Detect version and set variables accordingly.
SET VERIFY OFF
SET FEEDBACK OFF
COLUMN col NOPRINT NEW_VALUE v_orcl_vers

SELECT SUBSTR(version,1,3) col
  FROM product_component_version
 WHERE UPPER(product) LIKE 'ORACLE7%'
    OR UPPER(product) LIKE 'PERSONAL ORACLE%'
    OR UPPER(product) LIKE 'ORACLE8%';

COLUMN col NOPRINT NEW_VALUE start81
SELECT DECODE (upper('&v_orcl_vers'),
               '8.1', '/* Use 8i code! */',
               '/* Ignore 8i code') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE end81
SELECT DECODE (upper('&v_orcl_vers'),
               '8.1', '/* Use 8i code! */',
               'Ignore 8i code */') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE start73
SELECT DECODE (upper('&v_orcl_vers'),
               '8.1', '/* Ignore Oracle7 code! ',
               '/* Use Oracle7 code */') col  
  FROM dual;

COLUMN col NOPRINT NEW_VALUE end73
SELECT DECODE (upper('&v_orcl_vers'),
               '8.1', 'Ignore Oracle7 code! */',
               '/* Use Oracle7 code */') col  
  FROM dual;

SET FEEDBACK ON

@@utplsql.pks
@@utassert.pks
@@utresult.pks
@@utsuite.pks
@@utpackage.pks
@@uttest.pks
@@uttestcase.pks
@@utgen.pks

REM Create package bodies...

@@utplsql.pkb
@@utassert.pkb
@@utresult.pkb
@@utsuite.pkb
@@utpackage.pkb
@@uttest.pkb
@@uttestcase.pkb
@@utgen.pkb
